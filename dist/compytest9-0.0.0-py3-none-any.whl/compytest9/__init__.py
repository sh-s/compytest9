__version__ = "__version__ = '0.0.0'"

from compytest9.discomfortmethod import *
from compytest9.thermaldefinitions import *

